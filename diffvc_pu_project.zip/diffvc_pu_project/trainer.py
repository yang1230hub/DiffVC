
import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tqdm import tqdm
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    f1_score,
    recall_score
)

from models import TabDDPM, CLVSModel, FeatureConverter
from losses import FocalLoss, PULoss
from utils import find_best_threshold

def generate_views(
        diffusion_model,
        converter,
        x_num,
        x_cat,
        timesteps,
        alphas,
        alpha_bars,
        device
):

    bs = x_num.size(0)

    cat_cardinalities = [
        embed.num_embeddings
        for embed in converter.cat_embeds
    ]

    t_weak = torch.randint(
        1,
        max(2, int(timesteps * 0.15)),
        (bs,),
        device=device
    )

    t_mid = torch.randint(
        int(timesteps * 0.25),
        int(timesteps * 0.55),
        (bs,),
        device=device
    )

    t_strong = torch.randint(
        int(timesteps * 0.65),
        timesteps,
        (bs,),
        device=device
    )

    def generate_view(t_vec, return_diff_info=False):

        alpha_bar_t = alpha_bars[t_vec].view(-1, 1)

        noise = torch.randn_like(x_num)

        x_num_t = (
            torch.sqrt(alpha_bar_t) * x_num +
            torch.sqrt(1 - alpha_bar_t) * noise
        )

        x_cat_t_list = []

        for i, card in enumerate(cat_cardinalities):

            x_cat_i = F.one_hot(
                x_cat[:, i],
                num_classes=card
            ).float()

            prob = (
                alpha_bar_t * x_cat_i +
                (1 - alpha_bar_t) / card
            )

            x_cat_t_list.append(
                torch.distributions.Categorical(prob).sample()
            )

        if x_cat_t_list:
            x_cat_t = torch.stack(x_cat_t_list, dim=1)
        else:
            x_cat_t = torch.empty_like(x_cat)

        pred_num, pred_cat_logits = diffusion_model(
            x_num_t,
            x_cat_t,
            t_vec
        )

        x_num_gen = (
            (
                x_num_t -
                torch.sqrt(1 - alpha_bar_t) * pred_num
            ) / torch.sqrt(alpha_bar_t)
        )

        x_cat_gen_idx_list = []

        for i, card in enumerate(cat_cardinalities):

            x_cat_gen_idx_list.append(
                torch.argmax(
                    F.gumbel_softmax(
                        pred_cat_logits[i],
                        tau=0.5,
                        hard=True
                    ),
                    dim=1
                )
            )

        if x_cat_gen_idx_list:
            x_cat_gen_idx = torch.stack(
                x_cat_gen_idx_list,
                dim=1
            )
        else:
            x_cat_gen_idx = torch.empty_like(x_cat)

        x_gen = converter.convert(
            x_num_gen,
            x_cat_gen_idx
        )

        if return_diff_info:
            return x_gen, (
                pred_num,
                noise,
                pred_cat_logits,
                x_cat
            )

        return x_gen, None

    v1, _ = generate_view(t_weak)

    v2, _ = generate_view(t_mid)

    v3, diff_info = generate_view(
        t_strong,
        return_diff_info=True
    )

    return (
        (v1, v2, v3),
        (t_weak, t_mid, t_strong),
        diff_info
    )

def evaluate(model, converter, data_loader, device):

    model.eval()
    converter.eval()

    all_probs = []
    all_labels = []

    with torch.no_grad():

        for batch in data_loader:

            x_num = batch['num'].to(device)
            x_cat = batch['cat'].to(device)
            y = batch['label'].to(device)

            x = converter.convert(x_num, x_cat)

            _, logits = model(x)

            all_probs.extend(
                F.softmax(logits, dim=1)[:, 1]
                .cpu()
                .numpy()
            )

            all_labels.extend(y.cpu().numpy())

    return np.array(all_probs), np.array(all_labels)

def train_end_to_end(
        train_loader,
        val_loader,
        processor,
        device,
        config,
        pi_p,
        seed
):

    num_features = len(processor.num_cols)

    cat_cardinalities = processor.get_cat_cardinalities()

    input_dim = (
        num_features +
        len(cat_cardinalities) * config["embedding_dim"]
    )

    timesteps = config["diffusion_timesteps"]

    diffusion_model = TabDDPM(
        num_features,
        cat_cardinalities,
        embed_dim=config["embedding_dim"]
    ).to(device)

    clvs_model = CLVSModel(
        input_dim,
        config["transformer_dim"],
        proj_dim=32
    ).to(device)

    converter = FeatureConverter(
        num_features,
        cat_cardinalities,
        embed_dim=config["embedding_dim"]
    ).to(device)

    betas = torch.linspace(
        1e-4,
        0.02,
        timesteps
    ).to(device)

    alphas = 1. - betas

    alpha_bars = torch.cumprod(alphas, dim=0)

    optimizer = torch.optim.AdamW(
        list(diffusion_model.parameters()) +
        list(clvs_model.parameters()) +
        list(converter.parameters()),
        lr=config["lr"],
        weight_decay=1e-4
    )

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=config["epochs"],
        eta_min=1e-5
    )

    base_loss = FocalLoss()

    criterion_pu = PULoss(
        pi_p,
        base_loss=base_loss,
        nnpu=config["nnpu"]
    )

    criterion_mse = nn.MSELoss()

    history = {
        'train_loss': [],
        'val_auc': [],
        'val_pr': [],
        'val_f1': [],
        'val_recall': []
    }

    best_val_f1 = 0.0
    best_threshold_saved = 0.5

    save_dir = os.path.join(
        config["save_model_dir"],
        f"seed_{seed}"
    )

    os.makedirs(save_dir, exist_ok=True)

    for epoch in range(config["epochs"]):

        diffusion_model.train()
        clvs_model.train()
        converter.train()

        total_loss = 0.0

        pbar = tqdm(
            train_loader,
            desc=f"Seed {seed} Epoch {epoch + 1}/{config['epochs']}"
        )

        for batch in pbar:

            x_num = batch['num'].to(device)
            x_cat = batch['cat'].to(device)
            y = batch['label'].to(device)

            (v1, v2, v3), (
                t_w,
                t_m,
                t_s
            ), diff_info = generate_views(
                diffusion_model,
                converter,
                x_num,
                x_cat,
                timesteps,
                alphas,
                alpha_bars,
                device
            )

            pred_num, noise, pred_cat_logits, x_cat_orig = diff_info

            loss_diff_cat = sum([
                F.cross_entropy(
                    pred_cat_logits[i],
                    x_cat_orig[:, i]
                )
                for i in range(len(cat_cardinalities))
            ]) / max(1, len(cat_cardinalities))

            loss_diff = (
                F.mse_loss(pred_num, noise) +
                loss_diff_cat
            )

            h1, logits1 = clvs_model(v1)
            h2, logits2 = clvs_model(v2)
            h3, logits3 = clvs_model(v3)

            mask_pos = (y == 1)

            if mask_pos.sum() > 0:

                pu1 = criterion_pu(
                    logits1[mask_pos],
                    logits1[~mask_pos]
                )

                pu2 = criterion_pu(
                    logits2[mask_pos],
                    logits2[~mask_pos]
                )

                pu3 = criterion_pu(
                    logits3[mask_pos],
                    logits3[~mask_pos]
                )

                loss_cls = (
                    0.6 * pu1 +
                    0.3 * pu2 +
                    0.1 * pu3
                )

            else:
                loss_cls = torch.tensor(0.0, device=device)

            def info_nce(z1, z2):

                z1 = F.normalize(z1, dim=1)
                z2 = F.normalize(z2, dim=1)

                logits = torch.matmul(z1, z2.T) / config["temperature"]

                return F.cross_entropy(
                    logits,
                    torch.arange(z1.size(0), device=device)
                )

            loss_nce = (
                info_nce(h1, h2) +
                info_nce(h2, h3)
            )

            p1_12, p2_12 = clvs_model.get_projected(h1, h2)

            p2_23, p3_23 = clvs_model.get_projected(h2, h3)

            diff12 = (
                torch.abs(t_m.float() - t_w.float()) /
                timesteps
            )

            diff23 = (
                torch.abs(t_s.float() - t_m.float()) /
                timesteps
            )

            loss_ld = (
                criterion_mse(
                    F.cosine_similarity(p1_12, p2_12),
                    diff12
                )
                +
                criterion_mse(
                    F.cosine_similarity(p2_23, p3_23),
                    diff23
                )
            )

            sim12 = F.cosine_similarity(h1, h2)

            sim23 = F.cosine_similarity(h2, h3)

            loss_ali = (
                criterion_mse(
                    sim12,
                    torch.exp(-diff12 * 2.0)
                )
                +
                criterion_mse(
                    sim23,
                    torch.exp(-diff23 * 2.0)
                )
            )

            loss_re = F.relu(sim23 - sim12).mean()

            total_batch_loss = (
                config["cls_loss_weight"] * loss_cls +
                config["nce_loss_weight"] * loss_nce +
                config["ld_loss_weight"] * loss_ld +
                config["ali_loss_weight"] * loss_ali +
                config["re_loss_weight"] * loss_re +
                config["diff_loss_weight"] * loss_diff
            )

            optimizer.zero_grad()

            total_batch_loss.backward()

            torch.nn.utils.clip_grad_norm_(
                list(diffusion_model.parameters()) +
                list(clvs_model.parameters()) +
                list(converter.parameters()),
                config["grad_clip"]
            )

            optimizer.step()

            total_loss += total_batch_loss.item()

            pbar.set_postfix({
                'loss': total_batch_loss.item()
            })

        avg_train_loss = total_loss / len(train_loader)

        history['train_loss'].append(avg_train_loss)

        scheduler.step()

        val_probs, val_labels = evaluate(
            clvs_model,
            converter,
            val_loader,
            device
        )

        best_thresh = find_best_threshold(
            val_probs,
            val_labels
        )

        val_preds = (
            val_probs >= best_thresh
        ).astype(int)

        val_auc = roc_auc_score(val_labels, val_probs)

        val_pr = average_precision_score(
            val_labels,
            val_probs
        )

        val_f1 = f1_score(
            val_labels,
            val_preds,
            zero_division=0
        )

        val_rec = recall_score(
            val_labels,
            val_preds,
            zero_division=0
        )

        history['val_auc'].append(val_auc)
        history['val_pr'].append(val_pr)
        history['val_f1'].append(val_f1)
        history['val_recall'].append(val_rec)

        print(
            f"Seed {seed} Epoch {epoch + 1:3d} | "
            f"Loss: {avg_train_loss:.4f} | "
            f"AUC: {val_auc:.4f} | "
            f"PR-AUC: {val_pr:.4f} | "
            f"F1: {val_f1:.4f}"
        )

    return (
        clvs_model,
        diffusion_model,
        converter,
        history,
        best_threshold_saved
    )
