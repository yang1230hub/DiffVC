
import os
import random
import warnings
import numpy as np
import pandas as pd
import torch

from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    roc_auc_score,
    average_precision_score,
    f1_score,
    recall_score
)

from config import CONFIG
from utils import set_seed
from data_processor import TableDataProcessor, TabularDataset
from trainer import train_end_to_end, evaluate
from plotting import plot_training_history

warnings.filterwarnings('ignore')

def main():

    seeds = random.sample(range(1, 100000), 5)

    print("随机种子列表:", seeds)

    results = {
        'accuracy': [],
        'roc_auc': [],
        'pr_auc': [],
        'f1': [],
        'recall': []
    }

    for seed in seeds:

        set_seed(seed)

        CONFIG["seed"] = seed

        device = torch.device(CONFIG["device"])

        print(f"当前 seed={seed}")

        df = pd.read_csv(CONFIG["data_path"])

        df_train, df_temp = train_test_split(
            df,
            test_size=0.3,
            random_state=seed,
            stratify=df['y']
        )

        df_val, df_test = train_test_split(
            df_temp,
            test_size=0.5,
            random_state=seed,
            stratify=df_temp['y']
        )

        processor = TableDataProcessor()

        processor.fit(df_train, target_col='y')

        X_num_train, X_cat_train, y_train = processor.transform(df_train)

        X_num_val, X_cat_val, y_val = processor.transform(df_val)

        X_num_test, X_cat_test, y_test = processor.transform(df_test)

        pi_p = (y_train == 1).mean()

        pos_idx = np.where(y_train == 1)[0]

        n_pos = len(pos_idx)

        n_labeled = max(
            1,
            int(n_pos * CONFIG["pu_labeled_ratio"])
        )

        labeled_pos_idx = np.random.choice(
            pos_idx,
            size=n_labeled,
            replace=False
        )

        masked_y_train = np.zeros_like(y_train)

        masked_y_train[labeled_pos_idx] = 1

        train_loader = DataLoader(
            TabularDataset(
                X_num_train,
                X_cat_train,
                masked_y_train
            ),
            batch_size=CONFIG["batch_size"],
            shuffle=True,
            drop_last=True
        )

        val_loader = DataLoader(
            TabularDataset(
                X_num_val,
                X_cat_val,
                y_val
            ),
            batch_size=CONFIG["batch_size"],
            shuffle=False
        )

        test_loader = DataLoader(
            TabularDataset(
                X_num_test,
                X_cat_test,
                y_test
            ),
            batch_size=CONFIG["batch_size"],
            shuffle=False
        )

        (
            clvs_model,
            diffusion_model,
            converter,
            history,
            best_thresh
        ) = train_end_to_end(
            train_loader,
            val_loader,
            processor,
            device,
            CONFIG,
            pi_p,
            seed
        )

        save_dir = os.path.join(
            CONFIG["save_model_dir"],
            f"seed_{seed}"
        )

        plot_training_history(history, save_dir)

        test_probs, test_labels = evaluate(
            clvs_model,
            converter,
            test_loader,
            device
        )

        test_preds = (
            test_probs >= best_thresh
        ).astype(int)

        acc = accuracy_score(test_labels, test_preds)

        auc = roc_auc_score(test_labels, test_probs)

        pr_auc = average_precision_score(test_labels, test_probs)

        f1 = f1_score(test_labels, test_preds, zero_division=0)

        rec = recall_score(test_labels, test_preds, zero_division=0)

        results['accuracy'].append(acc)
        results['roc_auc'].append(auc)
        results['pr_auc'].append(pr_auc)
        results['f1'].append(f1)
        results['recall'].append(rec)

        print(f"Seed={seed} 测试结果")
        print(f"Accuracy : {acc:.4f}")
        print(f"ROC-AUC  : {auc:.4f}")
        print(f"PR-AUC   : {pr_auc:.4f}")
        print(f"F1       : {f1:.4f}")
        print(f"Recall   : {rec:.4f}")

    print("\n汇总结果")

    for metric in results:

        values = np.array(results[metric])

        print(
            f"{metric}: "
            f"{values.mean():.4f} ± {values.std():.4f}"
        )

if __name__ == "__main__":
    main()
