
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import CONFIG

class TabDDPM(nn.Module):

    def __init__(
            self,
            num_features,
            cat_cardinalities,
            embed_dim=64,
            hidden_dims=[256, 256]
    ):
        super().__init__()

        self.num_features = num_features

        self.cat_cardinalities = cat_cardinalities

        self.cat_embeds = nn.ModuleList([
            nn.Embedding(card, embed_dim)
            for card in cat_cardinalities
        ])

        input_dim = num_features + len(cat_cardinalities) * embed_dim

        time_embed_dim = 128

        self.time_mlp = nn.Sequential(
            nn.Linear(1, time_embed_dim),
            nn.SiLU(),
            nn.Linear(time_embed_dim, time_embed_dim)
        )

        layers = []

        prev_dim = input_dim + time_embed_dim

        for hd in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hd),
                nn.ReLU(),
                nn.Dropout(0.1)
            ])
            prev_dim = hd

        layers.append(
            nn.Linear(prev_dim, num_features + sum(cat_cardinalities))
        )

        self.net = nn.Sequential(*layers)

    def forward(self, x_num, x_cat, t):

        t_norm = t.float() / CONFIG["diffusion_timesteps"]

        t_emb = self.time_mlp(t_norm.unsqueeze(-1))

        cat_emb_list = [
            embed(x_cat[:, i])
            for i, embed in enumerate(self.cat_embeds)
        ]

        if cat_emb_list:
            h = torch.cat(
                [x_num, torch.cat(cat_emb_list, dim=1), t_emb],
                dim=1
            )
        else:
            h = torch.cat([x_num, t_emb], dim=1)

        out = self.net(h)

        num_out = out[:, :self.num_features]

        cat_out_splits = []

        start = self.num_features

        for card in self.cat_cardinalities:
            cat_out_splits.append(out[:, start:start + card])
            start += card

        return num_out, cat_out_splits

class FeatureConverter(nn.Module):

    def __init__(self, num_features, cat_cardinalities, embed_dim=64):
        super().__init__()

        self.cat_embeds = nn.ModuleList([
            nn.Embedding(card, embed_dim)
            for card in cat_cardinalities
        ])

    def convert(self, x_num, x_cat):

        if self.cat_embeds:
            cat_emb = torch.cat(
                [
                    embed(x_cat[:, i])
                    for i, embed in enumerate(self.cat_embeds)
                ],
                dim=1
            )
        else:
            cat_emb = torch.empty(
                (x_num.size(0), 0),
                device=x_num.device
            )

        return torch.cat([x_num, cat_emb], dim=1)

class TabTransformerBlock(nn.Module):

    def __init__(self, dim, num_heads=4, dropout=0.2):
        super().__init__()

        self.attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )

        self.dropout1 = nn.Dropout(dropout)

        self.se_fc = nn.Sequential(
            nn.Linear(dim, max(1, dim // 4)),
            nn.ReLU(),
            nn.Linear(max(1, dim // 4), dim),
            nn.Sigmoid()
        )

        self.alpha1 = nn.Parameter(torch.ones(1, dim))
        self.beta1 = nn.Parameter(torch.zeros(1, dim))

        self.alpha2 = nn.Parameter(torch.ones(1, dim))
        self.beta2 = nn.Parameter(torch.zeros(1, dim))

    def forward(self, x):

        x_seq = x.unsqueeze(1)

        attn_out, _ = self.attn(x_seq, x_seq, x_seq)

        attn_out = attn_out.squeeze(1)

        F_attn = self.dropout1(attn_out)

        x = self.alpha1 * x + self.beta1 * F_attn

        se_weight = self.se_fc(x)

        F_se = x * se_weight

        x = self.alpha2 * x + self.beta2 * F_se

        return x

class TabEncoder(nn.Module):

    def __init__(self, input_dim, hidden_dim=128, num_layers=2):
        super().__init__()

        self.input_proj = nn.Linear(input_dim, hidden_dim)

        self.blocks = nn.ModuleList([
            TabTransformerBlock(
                hidden_dim,
                num_heads=4,
                dropout=0.2
            )
            for _ in range(num_layers)
        ])

        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):

        x = self.input_proj(x)

        for block in self.blocks:
            x = block(x)

        return self.norm(x)

class CLVSModel(nn.Module):

    def __init__(self, input_dim, hidden_dim=128, proj_dim=32):
        super().__init__()

        self.encoder = TabEncoder(input_dim, hidden_dim)

        self.aug_module = nn.Sequential(
            nn.Linear(hidden_dim, proj_dim),
            nn.ReLU(),
            nn.Linear(proj_dim, proj_dim)
        )

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.LayerNorm(hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim // 2, 2)
        )

    def forward(self, x):

        h = self.encoder(x)

        return h, self.classifier(h)

    def get_projected(self, h1, h2):

        return (
            self.aug_module(h1),
            self.aug_module(h2)
        )
