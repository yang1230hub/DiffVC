
import os
import matplotlib.pyplot as plt

def plot_training_history(history, save_dir):

    os.makedirs(save_dir, exist_ok=True)

    epochs = range(1, len(history['train_loss']) + 1)

    plt.figure(figsize=(14, 6))

    plt.subplot(1, 2, 1)

    plt.plot(
        epochs,
        history['train_loss'],
        linewidth=2
    )

    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss')

    plt.grid(True)

    plt.subplot(1, 2, 2)

    plt.plot(epochs, history['val_auc'], label='AUC')
    plt.plot(epochs, history['val_pr'], label='PR-AUC')
    plt.plot(epochs, history['val_f1'], label='F1')
    plt.plot(epochs, history['val_recall'], label='Recall')

    plt.xlabel('Epoch')
    plt.ylabel('Score')

    plt.legend()

    plt.grid(True)

    plt.tight_layout()

    plt.savefig(
        os.path.join(save_dir, "training_history_metrics.png"),
        dpi=300
    )

    plt.close()
