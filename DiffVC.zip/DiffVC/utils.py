
import random
import numpy as np
import torch
from sklearn.metrics import f1_score

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def find_best_threshold(probs, labels):
    best_thresh = 0.5
    best_f1 = 0.0

    thresholds = np.linspace(0.05, 0.95, 50)

    for thresh in thresholds:
        preds = (probs >= thresh).astype(int)

        f1 = f1_score(labels, preds, zero_division=0)

        if f1 > best_f1:
            best_f1 = f1
            best_thresh = thresh

    return best_thresh if best_f1 > 0 else 0.5
