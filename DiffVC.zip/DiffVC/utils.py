import numpy as np
import torch
import torch.nn.functional as F

from sklearn.metrics import f1_score


def find_best_threshold(probs, labels):
    best_thresh = 0.5
    best_f1 = 0.0

    thresholds = np.linspace(0.05, 0.95, 50)

    for thresh in thresholds:
        preds = (probs >= thresh).astype(int)
        f1 = f1_score(labels, preds, zero_division=0)

        if f1 > best_f1:
            best_f1 = f1
            best_thresh = thresh

    return best_thresh


def evaluate(model, converter, data_loader, device):
    model.eval()
    converter.eval()

    all_probs = []
    all_labels = []

    with torch.no_grad():
        for batch in data_loader:
            x_num = batch['num'].to(device)
            x_cat = batch['cat'].to(device)
            y = batch['label'].to(device)

            x = converter.convert(x_num, x_cat)

            _, logits = model(x)

            all_probs.extend(
                F.softmax(logits, dim=1)[:, 1].cpu().numpy()
            )

            all_labels.extend(y.cpu().numpy())

    return np.array(all_probs), np.array(all_labels)