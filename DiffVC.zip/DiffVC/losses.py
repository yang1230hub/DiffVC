
import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLoss(nn.Module):

    def __init__(self, alpha=0.25, gamma=2.0, reduction='mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss

        if self.reduction == 'mean':
            return focal_loss.mean()

        return focal_loss.sum()

class PULoss(nn.Module):

    def __init__(self, pi_p, base_loss=None, nnpu=True):
        super().__init__()

        self.pi_p = pi_p
        self.base_loss = base_loss if base_loss is not None else FocalLoss()
        self.nnpu = nnpu

    def forward(self, logits_p, logits_u):

        device = logits_u.device if len(logits_u) > 0 else logits_p.device

        if len(logits_p) == 0:
            return torch.tensor(0.0, device=device)

        loss_p_pos = self.base_loss(
            logits_p,
            torch.ones(len(logits_p), dtype=torch.long, device=device)
        )

        loss_p_neg = self.base_loss(
            logits_p,
            torch.zeros(len(logits_p), dtype=torch.long, device=device)
        )

        loss_u_neg = self.base_loss(
            logits_u,
            torch.zeros(len(logits_u), dtype=torch.long, device=device)
        )

        if self.nnpu:
            loss = (
                self.pi_p * loss_p_pos +
                torch.clamp(loss_u_neg - self.pi_p * loss_p_neg, min=0.0)
            )
        else:
            loss = (
                self.pi_p * loss_p_pos +
                loss_u_neg -
                self.pi_p * loss_p_neg
            )

        return loss
