import os
import torch
import torch.nn as nn
import torch.nn.functional as F

from tqdm import tqdm
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    f1_score,
    recall_score
)

from models import TabDDPM, CLVSModel, FeatureConverter
from losses import FocalLoss, PULoss
from diffusion_utils import generate_views
from utils import evaluate, find_best_threshold


def train_end_to_end(
    train_loader,
    val_loader,
    processor,
    device,
    config,
    pi_p,
    seed
):
    num_features = len(processor.num_cols)

    cat_cardinalities = processor.get_cat_cardinalities()

    input_dim = (
        num_features +
        len(cat_cardinalities) * config["embedding_dim"]
    )

    timesteps = config["diffusion_timesteps"]

    diffusion_model = TabDDPM(
        num_features,
        cat_cardinalities,
        embed_dim=config["embedding_dim"]
    ).to(device)

    clvs_model = CLVSModel(
        input_dim,
        config["transformer_dim"],
        proj_dim=32
    ).to(device)

    converter = FeatureConverter(
        num_features,
        cat_cardinalities,
        embed_dim=config["embedding_dim"]
    ).to(device)

    betas = torch.linspace(1e-4, 0.02, timesteps).to(device)
    alphas = 1. - betas
    alpha_bars = torch.cumprod(alphas, dim=0)

    optimizer = torch.optim.AdamW(
        list(diffusion_model.parameters()) +
        list(clvs_model.parameters()) +
        list(converter.parameters()),
        lr=config["lr"],
        weight_decay=1e-4
    )

    criterion_pu = PULoss(
        pi_p,
        base_loss=FocalLoss(),
        nnpu=config["nnpu"]
    )

    criterion_mse = nn.MSELoss()

    best_val_f1 = 0.0

    save_dir = os.path.join(
        config["save_model_dir"],
        f"seed_{seed}"
    )

    os.makedirs(save_dir, exist_ok=True)

    for epoch in range(config["epochs"]):
        diffusion_model.train()
        clvs_model.train()
        converter.train()

        pbar = tqdm(train_loader)

        for batch in pbar:
            x_num = batch['num'].to(device)
            x_cat = batch['cat'].to(device)
            y = batch['label'].to(device)

            (v0, v1, v2, v3), _, diff_info = generate_views(
                diffusion_model,
                converter,
                x_num,
                x_cat,
                timesteps,
                alphas,
                alpha_bars,
                device
            )

            pred_num, noise, pred_cat_logits, x_cat_orig = diff_info

            loss_diff_cat = sum([
                F.cross_entropy(
                    pred_cat_logits[i],
                    x_cat_orig[:, i]
                )
                for i in range(len(cat_cardinalities))
            ]) / max(1, len(cat_cardinalities))

            loss_diff = (
                F.mse_loss(pred_num, noise) +
                loss_diff_cat
            )

            h1, logits1 = clvs_model(v1)
            h2, logits2 = clvs_model(v2)
            h3, logits3 = clvs_model(v3)

            mask_pos = (y == 1)

            if mask_pos.sum() > 0:
                pu1 = criterion_pu(logits1[mask_pos], logits1[~mask_pos])
                pu2 = criterion_pu(logits2[mask_pos], logits2[~mask_pos])
                pu3 = criterion_pu(logits3[mask_pos], logits3[~mask_pos])

                loss_cls = 0.6 * pu1 + 0.3 * pu2 + 0.1 * pu3
            else:
                loss_cls = torch.tensor(0.0, device=device)

            loss = loss_cls + loss_diff

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        val_probs, val_labels = evaluate(
            clvs_model,
            converter,
            val_loader,
            device
        )

        best_thresh = find_best_threshold(val_probs, val_labels)

        val_preds = (val_probs >= best_thresh).astype(int)

        val_f1 = f1_score(val_labels, val_preds)

        print(
            f"Epoch {epoch+1} | F1={val_f1:.4f}"
        )

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1

            torch.save(
                clvs_model.state_dict(),
                os.path.join(save_dir, "best_clvs_model.pth")
            )

    return clvs_model