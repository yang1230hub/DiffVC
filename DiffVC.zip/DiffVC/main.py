import os
import numpy as np
import pandas as pd
import torch

from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split

from config import CONFIG
from data import TableDataProcessor, TabularDataset
from trainer import train_end_to_end


def main():
    seeds = [0, 10, 20, 42, 100]

    for seed in seeds:
        print(f"Start training with seed={seed}")

        torch.manual_seed(seed)
        np.random.seed(seed)

        device = torch.device(CONFIG["device"])

        os.makedirs(CONFIG["save_model_dir"], exist_ok=True)

        df = pd.read_csv(CONFIG["data_path"])

        df_train, df_temp = train_test_split(
            df,
            test_size=0.3,
            random_state=seed,
            stratify=df['y']
        )

        df_val, df_test = train_test_split(
            df_temp,
            test_size=0.5,
            random_state=seed,
            stratify=df_temp['y']
        )

        processor = TableDataProcessor(seed=seed)

        processor.fit(df_train, target_col='y')

        X_num_train, X_cat_train, y_train = processor.transform(df_train)
        X_num_val, X_cat_val, y_val = processor.transform(df_val)

        pi_p = (y_train == 1).mean()

        pos_idx = np.where(y_train == 1)[0]

        n_pos = len(pos_idx)

        n_labeled = max(
            1,
            int(n_pos * CONFIG["pu_labeled_ratio"])
        )

        labeled_pos_idx = np.random.choice(
            pos_idx,
            size=n_labeled,
            replace=False
        )

        masked_y_train = np.zeros_like(y_train)

        masked_y_train[labeled_pos_idx] = 1

        train_loader = DataLoader(
            TabularDataset(
                X_num_train,
                X_cat_train,
                masked_y_train
            ),
            batch_size=CONFIG["batch_size"],
            shuffle=True,
            drop_last=True
        )

        val_loader = DataLoader(
            TabularDataset(
                X_num_val,
                X_cat_val,
                y_val
            ),
            batch_size=CONFIG["batch_size"],
            shuffle=False
        )

        train_end_to_end(
            train_loader,
            val_loader,
            processor,
            device,
            CONFIG,
            pi_p,
            seed
        )


if __name__ == "__main__":
    main()