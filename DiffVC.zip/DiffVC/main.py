
import warnings
warnings.filterwarnings('ignore')

from config import CONFIG
from utils import set_seed

def main():
    print("项目已拆分完成。")
    print("请将原 train_end_to_end、evaluate、generate_views 等函数补充到 train.py 中。")
    print("当前配置：")
    print(CONFIG)

if __name__ == "__main__":
    set_seed(42)
    main()
