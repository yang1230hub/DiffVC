import torch
import torch.nn.functional as F


def generate_views(
    diffusion_model,
    converter,
    x_num,
    x_cat,
    timesteps,
    alphas,
    alpha_bars,
    device
):
    bs = x_num.size(0)

    cat_cardinalities = [
        embed.num_embeddings
        for embed in converter.cat_embeds
    ]

    t_weak = torch.randint(
        1,
        max(2, int(timesteps * 0.15)),
        (bs,),
        device=device
    )

    t_mid = torch.randint(
        int(timesteps * 0.25),
        int(timesteps * 0.55),
        (bs,),
        device=device
    )

    t_strong = torch.randint(
        int(timesteps * 0.65),
        timesteps,
        (bs,),
        device=device
    )

    def generate_view(t_vec, return_diff_info=False):
        alpha_bar_t = alpha_bars[t_vec].view(-1, 1)

        noise = torch.randn_like(x_num)

        x_num_t = (
            torch.sqrt(alpha_bar_t) * x_num +
            torch.sqrt(1 - alpha_bar_t) * noise
        )

        x_cat_t_list = []

        for i, card in enumerate(cat_cardinalities):
            x_cat_i = F.one_hot(
                x_cat[:, i],
                num_classes=card
            ).float()

            prob = alpha_bar_t * x_cat_i + (1 - alpha_bar_t) / card

            x_cat_t_list.append(
                torch.distributions.Categorical(prob).sample()
            )

        x_cat_t = torch.stack(x_cat_t_list, dim=1)

        pred_num, pred_cat_logits = diffusion_model(
            x_num_t,
            x_cat_t,
            t_vec
        )

        x_num_gen = (
            x_num_t - torch.sqrt(1 - alpha_bar_t) * pred_num
        ) / torch.sqrt(alpha_bar_t)

        x_cat_gen_idx_list = []

        for i, card in enumerate(cat_cardinalities):
            x_cat_gen_idx_list.append(
                torch.argmax(
                    F.gumbel_softmax(
                        pred_cat_logits[i],
                        tau=0.5,
                        hard=True
                    ),
                    dim=1
                )
            )

        x_cat_gen_idx = torch.stack(x_cat_gen_idx_list, dim=1)

        x_gen = converter.convert(x_num_gen, x_cat_gen_idx)

        if return_diff_info:
            return (
                x_gen,
                (pred_num, noise, pred_cat_logits, x_cat)
            )

        return x_gen, None

    v0 = converter.convert(x_num, x_cat)
    v1, _ = generate_view(t_weak)
    v2, _ = generate_view(t_mid)
    v3, diff_info = generate_view(t_strong, return_diff_info=True)

    return (v0, v1, v2, v3), (t_weak, t_mid, t_strong), diff_info