import numpy as np
import torch

from torch.utils.data import Dataset
from sklearn.preprocessing import QuantileTransformer, LabelEncoder


class TableDataProcessor:
    def __init__(self, seed=42):
        self.num_scaler = QuantileTransformer(
            output_distribution='normal',
            random_state=seed
        )

        self.cat_encoders = {}
        self.num_cols = []
        self.cat_cols = []
        self.label_encoder = LabelEncoder()
        self.fitted = False

    def fit(self, df, target_col='y'):
        X = df.drop(columns=[target_col])
        y = df[target_col].values

        self.num_cols = X.select_dtypes(
            include=['int64', 'float64']
        ).columns.tolist()

        self.cat_cols = X.select_dtypes(
            include=['object', 'category']
        ).columns.tolist()

        if self.num_cols:
            self.num_scaler.fit(X[self.num_cols].fillna(0))

        for col in self.cat_cols:
            le = LabelEncoder()
            le.fit(X[col].fillna('Missing').astype(str))
            self.cat_encoders[col] = le

        self.label_encoder.fit(y)
        self.fitted = True

    def transform(self, df, target_col='y'):
        X = df.drop(columns=[target_col])
        y = df[target_col].values

        if self.num_cols:
            num_data = self.num_scaler.transform(
                X[self.num_cols].fillna(0)
            )
        else:
            num_data = np.empty((len(df), 0))

        cat_data = []

        for col in self.cat_cols:
            le = self.cat_encoders[col]

            encoded = le.transform(
                X[col].fillna('Missing').astype(str).apply(
                    lambda x: x if x in le.classes_ else le.classes_[0]
                )
            )

            cat_data.append(encoded.reshape(-1, 1))

        cat_data = (
            np.hstack(cat_data)
            if cat_data else np.empty((len(df), 0))
        )

        y_enc = self.label_encoder.transform(y)

        return (
            num_data.astype(np.float32),
            cat_data.astype(np.int64),
            y_enc.astype(np.int64)
        )

    def get_cat_cardinalities(self):
        return [len(le.classes_) for le in self.cat_encoders.values()]


class TabularDataset(Dataset):
    def __init__(self, num_data, cat_data, labels):
        self.num_data = torch.tensor(num_data, dtype=torch.float32)
        self.cat_data = torch.tensor(cat_data, dtype=torch.long)
        self.labels = torch.tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return {
            'num': self.num_data[idx],
            'cat': self.cat_data[idx],
            'label': self.labels[idx]
        }