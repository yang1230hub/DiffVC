
import torch

CONFIG = {
    "data_path": "D:/data/ex_3_data/ad_records.csv",
    "batch_size": 256,
    "diffusion_timesteps": 50,
    "embedding_dim": 64,
    "transformer_dim": 128,
    "transformer_layers": 4,
    "lr": 1e-3,
    "epochs": 200,
    "device": "cuda" if torch.cuda.is_available() else "cpu",
    "save_model_dir": "./checkpoints",
    "warmup_epochs": 5,
    "temperature": 0.15,
    "diff_loss_weight": 0.05,
    "cls_loss_weight": 1.0,
    "nce_loss_weight": 1.0,
    "ld_loss_weight": 0.5,
    "ali_loss_weight": 0.5,
    "re_loss_weight": 0.1,
    "grad_clip": 1.0,
    "pu_labeled_ratio": 0.8,
    "nnpu": True,
    "seed": None,
}
